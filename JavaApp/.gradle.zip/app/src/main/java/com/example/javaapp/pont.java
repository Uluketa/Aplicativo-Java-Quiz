package com.example.javaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class pont extends AppCompatActivity {

    ListView lista;
    ArrayAdapter<String> adapter;
    ArrayList<String> arrayList;
    UserDAO db = new UserDAO(this);

    String nome;
    int pont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pont);

        Intent it = getIntent();
        Bundle parametros = it.getExtras();

        nome = parametros.getString("nome");
        pont = parametros.getInt("pont");
        lista = (ListView) findViewById(R.id.listview);

        listarAlunos();
    }

    public void listarAlunos() {

        arrayList = new ArrayList<String>();
        adapter = new ArrayAdapter<String>(pont.this,
                android.R.layout.simple_list_item_1, arrayList);
        lista.setAdapter(adapter);

}
}