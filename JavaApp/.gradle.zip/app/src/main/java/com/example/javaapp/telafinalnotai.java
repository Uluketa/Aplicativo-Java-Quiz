package com.example.javaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class telafinalnotai extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telafinalnotai);

        TextView nome = (TextView) findViewById(R.id.nome);
        TextView pont = (TextView) findViewById(R.id.pont);

        Intent it = getIntent();

        Bundle parametros = it.getExtras();
        String nome1 = parametros.getString("nome");
        int pont1 = parametros.getInt("pont");

        nome.setText("OPS, Try again  "+nome1);
        pont.setText(""+pont1);
    }

    public void refazer(View view) {
        Intent it2 = new Intent(telafinalnotai.this, MainActivity.class);
        startActivity(it2);
    }

    String nome;
    int pont;

    public void pontuacao(View view) {
        Intent it = getIntent();
        Bundle parametros = it.getExtras();

        nome = parametros.getString("nome");
        pont = parametros.getInt("pont");

        Intent it2 = new Intent(telafinalnotai.this, pont.class);
        it2.putExtra("nome", nome);
        it2.putExtra("pont", pont);
        startActivity(it2);
    }
}