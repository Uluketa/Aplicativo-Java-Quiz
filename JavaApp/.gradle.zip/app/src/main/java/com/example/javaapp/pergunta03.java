package com.example.javaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class pergunta03 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta03);

        Intent it18 = getIntent();
        String inf = it18.getStringExtra("msg");
    }

    String nome;
    int pont;

    public void errada(View view) {
        Intent it = getIntent();
        Bundle parametros = it.getExtras();

        pont = parametros.getInt("pont");

        Intent it2 = new Intent(pergunta03.this, pergunta04.class);
        it2.putExtra("pont", pont);
        startActivity(it2);
    }

    public void certo(View view) {
        Intent it = getIntent();
        Bundle parametros = it.getExtras();

        pont = parametros.getInt("pont");
        pont = (pont + 1);

        Intent it2 = new Intent(pergunta03.this, pergunta04.class);
        it2.putExtra("pont", pont);
        startActivity(it2);
    }
}