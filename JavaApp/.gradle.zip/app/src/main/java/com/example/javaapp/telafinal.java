package com.example.javaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class telafinal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telafinal);

        TextView nome = (TextView) findViewById(R.id.nome);

        Intent it = getIntent();

        if (it != null)
        {
            Bundle parametros = it.getExtras();

            String nome1 = parametros.getString("nome");
            int pont = parametros.getInt("pont");
            nome.setText("Congratulations "+nome1);
        }

        else
        {
            Bundle parametros = it.getExtras();
            int pont = parametros.getInt("pont");
        }
    }

    public void refazer(View view) {
        Intent it2 = new Intent(telafinal.this, MainActivity.class);
        startActivity(it2);
    }

    String nome;
    int pont;

    public void pontuacao(View view) {
        Intent it = getIntent();
        Bundle parametros = it.getExtras();

        nome = parametros.getString("nome");
        pont = parametros.getInt("pont");

        Intent it2 = new Intent(telafinal.this, pont.class);
        it2.putExtra("nome", nome);
        it2.putExtra("pont", pont);
        startActivity(it2);
    }
}