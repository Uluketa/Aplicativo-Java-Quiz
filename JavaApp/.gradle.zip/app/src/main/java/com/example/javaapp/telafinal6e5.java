package com.example.javaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class telafinal6e5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telafinal6e5);

        TextView nome = (TextView) findViewById(R.id.nome);
        TextView pont = (TextView) findViewById(R.id.pont);

        Intent it = getIntent();

        Bundle parametros = it.getExtras();
        String nome1 = parametros.getString("nome");
        int pont1 = parametros.getInt("pont");

        nome.setText("Congratulations "+nome1);
        pont.setText(""+pont1);
    }

    public void refazer(View view) {
        Intent it2 = new Intent(telafinal6e5.this, MainActivity.class);
        startActivity(it2);
    }

    String nome;
    int pont;

    public void pontuacao(View view) {
        Intent it = getIntent();
        Bundle parametros = it.getExtras();

        nome = parametros.getString("nome");
        pont = parametros.getInt("pont");

        Intent it2 = new Intent(telafinal6e5.this, pont.class);
        it2.putExtra("nome", nome);
        it2.putExtra("pont", pont);
        startActivity(it2);
    }
}