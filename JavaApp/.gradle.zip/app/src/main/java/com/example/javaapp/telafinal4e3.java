package com.example.javaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class telafinal4e3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telafinal4e3);

        TextView nome = (TextView) findViewById(R.id.nome);
        TextView pont = (TextView) findViewById(R.id.pont);

        Intent it = getIntent();

        Bundle parametros = it.getExtras();
        String nome1 = parametros.getString("nome");
        int pont1 = parametros.getInt("pont");

        nome.setText("Congratulations "+nome1);
        pont.setText(""+pont1);
    }

    String nome;
    int pont;

    public void refazer(View view) {
        Intent it2 = new Intent(telafinal4e3.this, MainActivity.class);
        startActivity(it2);
    }

    public void pontuacao(View view) {
        Intent it = getIntent();
        Bundle parametros = it.getExtras();

        nome = parametros.getString("nome");
        pont = parametros.getInt("pont");

        Intent it2 = new Intent(telafinal4e3.this, pont.class);
        it2.putExtra("nome", nome);
        it2.putExtra("pont", pont);
        startActivity(it2);
    }

}