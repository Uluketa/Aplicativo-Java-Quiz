package com.example.javaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class Cadastro extends AppCompatActivity {

    EditText nome, senha, email;
    UserDAO db = new UserDAO(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        nome = (EditText) findViewById(R.id.editTextTextPersonName);
        senha = (EditText) findViewById(R.id.editTextTextPassword);
        email = (EditText) findViewById(R.id.editTextTextEmailAddress);
    }

    public void onClick(View v) {
        User u = new User();
        u.setNome(nome.getText().toString());
        u.setEmail(email.getText().toString());
        u.setSenha(senha.getText().toString());
        db = new UserDAO(Cadastro.this);
        db.cadastrar(u);
        Toast.makeText(Cadastro.this, "Cadastrado", Toast.LENGTH_SHORT).show();

        Intent it = new Intent(Cadastro.this, MainActivity.class);
        startActivity(it);
    }

    public void entro(View view) {
        Intent it = new Intent(Cadastro.this, MainActivity.class);
        startActivity(it);
    }
}