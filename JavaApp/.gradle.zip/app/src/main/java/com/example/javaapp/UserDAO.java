package com.example.javaapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class UserDAO extends SQLiteOpenHelper {

    private static String database = "jogo";
    private static int versao = 1;

    public UserDAO(@Nullable Context context) {
        super(context, database, null, versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        String sql = "create table usuario(id INTEGER"
                + " PRIMARY KEY AUTOINCREMENT ," + " nome TEXT, email TEXT, senha TEXT, pont INT); ";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int v1, int v2) {
        // TODO Auto-generated method stub
        String sql = "drop table if exists usuario";
        db.execSQL(sql);
        this.onCreate(db);
    }

    // Cadastar
    public void cadastrar(User u) {
        ContentValues v = new ContentValues();
        v.put("nome", u.getNome());
        v.put("email", u.getEmail());
        v.put("senha", u.getSenha());
        getWritableDatabase().insert("usuario", null, v);
    }
}
